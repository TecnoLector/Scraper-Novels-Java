package com.extractor.mi_extractor;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractorContenido {
    
    // Lista de selectores de título, ordenados por prioridad
    private final String[] selectoresTituloCandidatos = {
        "h1[class*='title']", "h2[class*='title']", "h3.text-center",
        "p > strong", "strong", "h1", "h2", "h3", "h4"
    };
    
    // Lista de selectores para el contenedor del capítulo
    private final String[] selectoresContenedor = {
     "div.skn-chp-chapter-content","div#chapter-content"
    };

    public Capitulo extraer(String html) {
        Document doc = Jsoup.parse(html);
        
        Element tituloElement = null;
        Element contenidoElement = null;

        // Patrón para buscar "Capitulo" o "Capítulo", ignorando mayúsculas/minúsculas
        Pattern patronTituloValido = Pattern.compile("Cap[ií]tulo\\s*\\d+", Pattern.CASE_INSENSITIVE);

        // Bucle para probar cada selector hasta encontrar un título válido
        for (String selector : selectoresTituloCandidatos) {
            for (Element candidato : doc.select(selector)) {
                // Bloque de seguridad para evitar errores con etiquetas vacías
                if (candidato != null && candidato.hasText()) {
                    String textoCandidato = candidato.text();
                    Matcher matcher = patronTituloValido.matcher(textoCandidato);
                    if (matcher.find()) {
                        tituloElement = candidato; // ¡Encontrado!
                        System.out.println("Título encontrado con el selector: " + selector);
                        break; 
                    }
                }
            }
            if (tituloElement != null) {
                break;
            }
        }

        // Búsqueda flexible de contenido
        for (String selector : selectoresContenedor) {
            contenidoElement = doc.selectFirst(selector);
            if (contenidoElement != null) {
                System.out.println("Contenido encontrado con el selector: " + selector);
                break;
            }
        }

        // Plan B para el título si todo lo demás falla
        if (tituloElement == null) {
            System.out.println("Advertencia: No se encontró el título con los selectores habituales. Intentando Plan B (etiqueta <title>)...");
            tituloElement = doc.selectFirst("title");
            if (tituloElement != null) System.out.println("Título encontrado en la etiqueta <title>.");
        }

        if (tituloElement != null && contenidoElement != null) {
            String titulo = tituloElement.text();
            
            // Limpieza del contenido
            contenidoElement.select("miad-block2, miad-block3").remove(); // Elimina publicidad
            String contenidoHtml = contenidoElement.html().replace("&nbsp;", "&#160;");

            // Intenta eliminar el título del contenido para no duplicarlo
            try {
                Element tituloEnContenido = contenidoElement.selectFirst(tituloElement.cssSelector());
                if (tituloEnContenido != null) {
                    if (tituloEnContenido.parent() != null && tituloEnContenido.parent().tagName().equalsIgnoreCase("p")) {
                        tituloEnContenido.parent().remove();
                    } else {
                        tituloEnContenido.remove();
                    }
                    contenidoHtml = contenidoElement.html().replace("&nbsp;", "&#160;");
                }
            } catch (Exception e) { /* Ignorar si falla */ }

            return new Capitulo(titulo, contenidoHtml);
        }
        
        System.err.println("Error Crítico: No se pudo encontrar el título o el contenido del capítulo.");
        guardarHtmlDeError(html);
        return null;
    }
    
    private void guardarHtmlDeError(String html) {
        try {
            String nombreArchivoDebug = "debug_pagina_fallida.html";
            Files.writeString(Paths.get(nombreArchivoDebug), html);
            System.out.println("!!! Se ha guardado el HTML de la página fallida en el archivo: " + nombreArchivoDebug);
        } catch (IOException e) {
            System.err.println("No se pudo guardar el archivo de depuración.");
        }
    }
}
package com.extractor.mi_extractor;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.StandardCopyOption;
import java.nio.charset.StandardCharsets;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.stream.Stream;

public class MenuExtractor {

    public static void iniciar(Scanner scanner) {
        long tiempoInicio = System.currentTimeMillis();

        System.out.println("\n--- Extractor de Capítulos ---");
        System.out.println("Introduce la ruta de la carpeta donde se guardará la novela:");
        String rutaDeGuardado = scanner.nextLine();
        Path rutaBase = Paths.get(rutaDeGuardado);

        try {
            Files.createDirectories(rutaBase);

        } catch (IOException e) {
            System.err.println("Error CRÍTICO al crear carpeta o inicializar estructura: " + e.getMessage());
            return;
        }

        System.out.println("Introduce el NOMBRE ESPECÍFICO de esta novela (se creará una carpeta con este nombre):");
        String nombreNovela = scanner.nextLine();
        if (nombreNovela.isBlank()) {
            System.err.println("Error: El nombre de la novela no puede estar vacío.");
            return;
        }

        Path rutaNovela = rutaBase.resolve(nombreNovela);

        try {
            Files.createDirectories(rutaNovela);
            System.out.println("Usando carpeta de novela: " + rutaNovela);
            inicializarEstructuraEPUB(rutaNovela);
        } catch (IOException e) {
            System.err.println("Error CRÍTICO al crear carpeta de novela o inicializar estructura: " + e.getMessage());
            e.printStackTrace();
            return;
        }

        System.out.println("\n¿Qué quieres hacer?");
        System.out.println("1. Descargar una cantidad específica (en lote).");
        System.out.println("2. Descargar HASTA un número de capítulo.");
        System.out.println("3. BUSCAR un capítulo por su NÚMERO.");
        System.out.println("4. Descargar un RANGO de capítulos.");
        System.out.println("5. Descargar una LISTA específica de capítulos.");
        System.out.print("Elige una opción (1-5): ");
        int opcion;
        try {
            opcion = scanner.nextInt();
        } catch (java.util.InputMismatchException e) {
            opcion = -1;
        }
        scanner.nextLine();

        try {
            String rutaNovelaStr = rutaNovela.toString();
            if (opcion == 1 || opcion == 2) {
                descargarEnLote(opcion, scanner, rutaNovelaStr);
            } else if (opcion == 3) {
                buscarYDescargarCapitulo(scanner, rutaNovelaStr);
            } else if (opcion == 4) {
                descargarRangoDeCapitulos(scanner, rutaNovelaStr);
            } else if (opcion == 5) {
                descargarListaEspecifica(scanner, rutaNovelaStr);
            } else {
                System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            /* ... */ }

        long tiempoFin = System.currentTimeMillis();
        long tiempoTotalMillis = tiempoFin - tiempoInicio;
        long minutos = TimeUnit.MILLISECONDS.toMinutes(tiempoTotalMillis);
        long segundos = TimeUnit.MILLISECONDS.toSeconds(tiempoTotalMillis) - TimeUnit.MINUTES.toSeconds(minutos);

        System.out.println("\n--- Fin del Módulo Extractor ---");
        System.out.println("Tiempo de ejecución: " + minutos + " min " + segundos + " s.");
    }

    private static void inicializarEstructuraEPUB(Path rutaBase) throws IOException {
        Path rutaMimetype = rutaBase.resolve("mimetype");

        if (Files.notExists(rutaMimetype)) {
            System.out.println("Detectada carpeta nueva o incompleta. Creando estructura EPUB base...");

            Files.createDirectories(rutaBase.resolve("META-INF"));
            Path rutaOEBPS = rutaBase.resolve("OEBPS");
            Files.createDirectories(rutaOEBPS);
            Files.createDirectories(rutaOEBPS.resolve("Text"));
            Path rutaStyles = rutaOEBPS.resolve("Styles"); 
            Path rutaFonts = rutaOEBPS.resolve("Fonts");
            Files.createDirectories(rutaStyles);
            Files.createDirectories(rutaFonts);
            Files.createDirectories(rutaOEBPS.resolve("Images"));
            Files.writeString(rutaMimetype, "application/epub+zip", StandardCharsets.US_ASCII);

            copiarRecursoDesdeJar("/recursos/stylesheet.css", rutaStyles.resolve("stylesheet.css"));

            System.out.println("Buscando y copiando fuentes (.ttf, .otf)...");
            try {
                String rutaJarFonts = "/recursos/fonts";
                URL urlFonts = MenuExtractor.class.getResource(rutaJarFonts);

                if (urlFonts != null) {
                    URI uriFonts = urlFonts.toURI();
                    Path pathFonts;
                    FileSystem fileSystem = null;

                    if (uriFonts.getScheme().equals("jar")) {
                        try {
                            fileSystem = FileSystems.getFileSystem(uriFonts);
                        } catch (java.nio.file.FileSystemNotFoundException e) {
                            fileSystem = FileSystems.newFileSystem(uriFonts, Collections.emptyMap());
                        }
                        pathFonts = fileSystem.getPath(rutaJarFonts);
                    } else {
                        pathFonts = Paths.get(uriFonts);
                    }
                    PathMatcher fontMatcher = FileSystems.getDefault().getPathMatcher("glob:**.{ttf,otf}");
                    try (Stream<Path> paths = Files.walk(pathFonts, 1)) {
                        paths.filter(Files::isRegularFile)
                                .filter(fontMatcher::matches)
                                .forEach(fontPath -> {
                                    String nombreFuente = fontPath.getFileName().toString();
                                    String rutaCompletaEnJar = rutaJarFonts + "/" + nombreFuente;
                                    Path destinoFuente = rutaFonts.resolve(nombreFuente);
                                    copiarRecursoDesdeJar(rutaCompletaEnJar, destinoFuente);
                                });
                    }

                    // Cerrar el sistema de archivos del JAR si lo abrimos nosotros
                    // ¡OJO! No cerrar si lo obtuvimos con getFileSystem, podría ser usado por otros
                    // if (fileSystem != null && uriFonts.getScheme().equals("jar") &&
                    // !FileSystems.getFileSystem(uriFonts).equals(fileSystem)) {
                    // fileSystem.close(); // Comentado por precaución, el cierre automático a veces
                    // da problemas
                    // }

                } else {
                    System.err.println("ADVERTENCIA: No se encontró la carpeta de recursos '/recursos/fonts'.");
                }

            } catch (URISyntaxException | IOException e) {
                System.err.println("Error al intentar listar o copiar fuentes: " + e.getMessage());
                e.printStackTrace(); // Mostrar más detalles del error
            }

            System.out.println("¡Estructura EPUB base creada con éxito!");
        } else {
            System.out.println("Estructura EPUB detectada. Añadiendo capítulos...");
        }
    }

    /**
     * Copia un recurso desde el classpath a una ruta de destino en el disco.
     */
    private static void copiarRecursoDesdeJar(String rutaEnJar, Path rutaDestino) {
        try (InputStream is = MenuExtractor.class.getResourceAsStream(rutaEnJar)) {
            if (is == null) {
                System.err.println("ADVERTENCIA: Recurso no encontrado en el JAR: " + rutaEnJar);
                return;
            }
            Files.createDirectories(rutaDestino.getParent());
            Files.copy(is, rutaDestino, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Recurso copiado a: " + rutaDestino);
        } catch (IOException | NullPointerException e) {
            System.err.println("Error al copiar recurso '" + rutaEnJar + "': " + e.getMessage());
        }
    }

    private static void descargarEnLote(int opcion, Scanner scanner, String rutaNovelaStr) {
        System.out.println("Introduce la URL del PRIMER capítulo para empezar:");
        String urlInicial = scanner.nextLine();
        int limite = 0;

        if (opcion == 1) {
            System.out.print("¿Cuántos capítulos quieres descargar?: ");
            limite = scanner.nextInt();
        } else {
            System.out.print("¿Hasta qué número de capítulo quieres descargar?: ");
            limite = scanner.nextInt();
        }
        scanner.nextLine();

        Scraper scraper = new Scraper();
        int capitulosProcesados = 0;
        try {
            scraper.navegarA(urlInicial);

            while (true) {
                Capitulo capitulo = procesarUnCapitulo(scraper, null, rutaNovelaStr, capitulosProcesados + 1);

                if (capitulo == null)
                    break;
                capitulosProcesados++;

                if (opcion == 1 && capitulosProcesados >= limite) {
                    System.out.println("Se ha alcanzado la cantidad de capítulos a descargar.");
                    break;
                }
                if (opcion == 2) {
                    int numCapituloActual = extraerNumeroDeTitulo(capitulo.getTitulo());
                    if (numCapituloActual > 0 && numCapituloActual >= limite) {
                        System.out.println("Se ha alcanzado el capítulo final (" + limite + ").");
                        break;
                    } else if (numCapituloActual == 0) {
                        System.out
                                .println("Advertencia: No se pudo extraer número del título: " + capitulo.getTitulo());
                    }
                }

                if (!scraper.irAlSiguienteCapitulo()) {
                    System.out.println("No hay más capítulos. Terminando.");
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("Ocurrió un error general en la aplicación: " + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("Total de capítulos guardados en esta sesión: " + capitulosProcesados);
            scraper.cerrar();
        }
    }

    private static void buscarYDescargarCapitulo(Scanner scanner, String rutaNovelaStr) {
        System.out.println("Introduce la URL de la PÁGINA PRINCIPAL de la novela:");
        String urlIndice = scanner.nextLine();

        System.out.print("¿Qué número de capítulo quieres descargar?: ");
        int numeroCapituloBuscado = scanner.nextInt();
        scanner.nextLine();

        Scraper scraper = new Scraper();
        IndiceExtractor extractorIndice = new IndiceExtractor();

        try {
            System.out.println("Analizando la página de índice...");
            scraper.navegarA(urlIndice);
            String htmlIndice = scraper.obtenerHtmlDeIndice();

            Map<Integer, String> mapaDeCapitulos = extractorIndice.extraerEnlaces(htmlIndice, urlIndice);

            if (mapaDeCapitulos.containsKey(numeroCapituloBuscado)) {
                String urlCapitulo = mapaDeCapitulos.get(numeroCapituloBuscado);
                System.out.println("¡Enlace encontrado! URL: " + urlCapitulo);
                procesarUnCapitulo(scraper, urlCapitulo, rutaNovelaStr, numeroCapituloBuscado);
            } else {
                System.err.println("Error: No se pudo encontrar el capítulo número " + numeroCapituloBuscado + ".");
            }
        } catch (Exception e) {
            System.err.println("Ocurrió un error al buscar el capítulo: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scraper.cerrar();
        }
    }

    private static void descargarRangoDeCapitulos(Scanner scanner, String rutaNovelaStr) {
        System.out.println("Introduce la URL de la PÁGINA PRINCIPAL de la novela:");
        String urlIndice = scanner.nextLine();

        System.out.print("¿Desde qué número de capítulo quieres empezar?: ");
        int capituloInicio = scanner.nextInt();

        System.out.print("¿Hasta qué número de capítulo quieres descargar?: ");
        int capituloFin = scanner.nextInt();
        scanner.nextLine();

        Scraper scraper = new Scraper();
        IndiceExtractor extractorIndice = new IndiceExtractor();
        int capitulosDescargados = 0;

        try {
            System.out.println("Analizando la página de índice...");
            scraper.navegarA(urlIndice);
            String htmlIndice = scraper.obtenerHtmlDeIndice();

            Map<Integer, String> mapaDeCapitulos = extractorIndice.extraerEnlaces(htmlIndice, urlIndice);

            for (int i = capituloInicio; i <= capituloFin; i++) {
                if (mapaDeCapitulos.containsKey(i)) {
                    String urlCapitulo = mapaDeCapitulos.get(i);
                    Capitulo cap = procesarUnCapitulo(scraper, urlCapitulo, rutaNovelaStr, i);
                    if (cap != null) {
                        capitulosDescargados++;
                    }
                } else {
                    System.err.println("Advertencia: No se encontró el capítulo número " + i + ". Saltando...");
                }
            }
        } catch (Exception e) {
            System.err.println("Ocurrió un error al descargar el rango: " + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("Total de capítulos guardados en esta sesión: " + capitulosDescargados);
            scraper.cerrar();
        }
    }

    private static void descargarListaEspecifica(Scanner scanner, String rutaNovelaStr) {
        System.out.println("Introduce la URL de la PÁGINA PRINCIPAL de la novela:");
        String urlIndice = scanner.nextLine();

        System.out.println("Introduce los números de capítulo separados por comas (ej: 10, 25, 100):");
        String listaDeNumerosStr = scanner.nextLine();

        List<Integer> numerosADescargar = new ArrayList<>();
        try {
            for (String numeroStr : listaDeNumerosStr.split(",")) {
                numerosADescargar.add(Integer.parseInt(numeroStr.trim()));
            }
        } catch (NumberFormatException e) {
            System.err.println("Error: La lista de capítulos contiene un valor no numérico.");
            return;
        }

        Scraper scraper = new Scraper();
        IndiceExtractor extractorIndice = new IndiceExtractor();
        int capitulosDescargados = 0;

        try {
            System.out.println("Analizando la página de índice...");
            scraper.navegarA(urlIndice);
            String htmlIndice = scraper.obtenerHtmlDeIndice();

            Map<Integer, String> mapaDeCapitulos = extractorIndice.extraerEnlaces(htmlIndice, urlIndice);

            for (int numeroBuscado : numerosADescargar) {
                if (mapaDeCapitulos.containsKey(numeroBuscado)) {
                    String urlCapitulo = mapaDeCapitulos.get(numeroBuscado);
                    Capitulo cap = procesarUnCapitulo(scraper, urlCapitulo, rutaNovelaStr, numeroBuscado);
                    if (cap != null) {
                        capitulosDescargados++;
                    }
                } else {
                    System.err.println(
                            "Advertencia: No se encontró el capítulo número " + numeroBuscado + ". Saltando...");
                }
            }
        } catch (Exception e) {
            System.err.println("Ocurrió un error al descargar la lista: " + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("Total de capítulos guardados en esta sesión: " + capitulosDescargados);
            scraper.cerrar();
        }
    }

    private static Capitulo procesarUnCapitulo(Scraper scraper, String url, String rutaDeGuardado, int numeroCapitulo)
            throws Exception {
        if (url != null)
            scraper.navegarA(url);

        System.out.println("\n--- Procesando Capítulo #" + numeroCapitulo + " ---");
        String html = scraper.obtenerHtmlDePagina();

        ExtractorContenido extractor = new ExtractorContenido();
        EscritorArchivo escritor = new EscritorArchivo();

        Capitulo capitulo = extractor.extraer(html);
        if (capitulo != null) {
            escritor.guardarCapitulo(capitulo, rutaDeGuardado, numeroCapitulo);
            return capitulo;
        } else {
            System.err.println("No se pudo extraer el contenido del capítulo. Abortando.");
            return null;
        }
    }

    private static int extraerNumeroDeTitulo(String titulo) {
        if (titulo == null)
            return 0;
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(titulo);
        if (matcher.find()) {
            try {
                return Integer.parseInt(matcher.group());
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }
}
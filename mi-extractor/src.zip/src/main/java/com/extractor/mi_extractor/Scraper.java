package com.extractor.mi_extractor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class Scraper {
    private WebDriver driver;
    private WebDriverWait wait;
    private JavascriptExecutor js;

    private final String selectorContenidoCapitulo = "div.skn-chp-chapter-content";
    private final String xPathPestanaContenido = "//a[@class='nav-link' and contains(text(), 'Contenido')]";
    private final String selectorEncabezadoVolumen = "mat-expansion-panel-header";
    private final String selectorElementoDeLaLista = "div.skn-nvl-chp-element";
    private final String xPathBotonSiguiente = "//button[.//span[contains(text(), 'Siguiente')]]";

    public Scraper() {
        ChromeOptions options = new ChromeOptions();
        //options.addArguments("--headless=new");
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        options.addArguments("--blink-settings=imagesEnabled=false");
        //options.addArguments("--disable-javascript");
        this.driver = new ChromeDriver(options);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(1));
        this.js = (JavascriptExecutor) driver;
    }

    public void navegarA(String url) {
        System.out.println("Navegando a: " + url);
        driver.get(url);
    }

    public String obtenerHtmlDePagina() {
        System.out.println("Esperando a que el contenido del capítulo cargue...");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(selectorContenidoCapitulo)));
        System.out.println("Página de capítulo cargada. Obteniendo código fuente...");
        return driver.getPageSource();
    }

    public String obtenerHtmlDeIndice() throws InterruptedException {
        // 1. Esperar a que la pestaña "Contenido" esté visible y hacer clic con
        // JavaScript
        System.out.println("Esperando a que la pestaña 'Contenido' esté presente...");
        WebElement pestanaContenido = wait
                .until(ExpectedConditions.presenceOfElementLocated(By.xpath(xPathPestanaContenido)));
        js.executeScript("arguments[0].click();", pestanaContenido);
        System.out.println("Clic en la pestaña 'Contenido'.");

        // 2. Esperar a que los encabezados de los volúmenes carguen
        System.out.println("Esperando a que los volúmenes carguen...");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(selectorEncabezadoVolumen)));
        Thread.sleep(1000); // Pequeña pausa para asegurar que todo esté listo

        // 3. Encontrar TODOS los encabezados de volúmenes y hacer clic en cada uno para
        // desplegarlos
        System.out.println("Desplegando todos los volúmenes...");
        List<WebElement> volumenes = driver.findElements(By.cssSelector(selectorEncabezadoVolumen));
        System.out.println("Se encontraron " + volumenes.size() + " volúmenes.");
        for (WebElement volumen : volumenes) {
            try {
                // Usamos JavaScript para el clic para evitar problemas de elementos
                // superpuestos
                js.executeScript("arguments[0].click();", volumen);
                Thread.sleep(250); // Pausa corta entre clics para no saturar la página
            } catch (Exception e) {
                System.err.println("Advertencia: no se pudo hacer clic en un encabezado de volumen.");
            }
        }

        // 4. Esperar a que al menos un capítulo esté visible después de desplegar
        System.out.println("Esperando a que la lista de capítulos esté visible...");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(selectorElementoDeLaLista)));

        System.out.println("¡Toda la lista de capítulos está cargada! Obteniendo código fuente...");
        return driver.getPageSource();
    }

    public boolean irAlSiguienteCapitulo() {
        try {
            WebElement botonSiguiente = driver.findElement(By.xpath(xPathBotonSiguiente));
            js.executeScript("arguments[0].click();", botonSiguiente);
            System.out.println("Haciendo clic en el botón 'Siguiente'...");
           // System.out.println("Esperando 0.5 segundos a que cargue el nuevo capítulo...");
            Thread.sleep(2000);
           // System.out.println("Esperando a que cargue el contenido del SIGUIENTE capítulo...");
            //wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(selectorContenidoCapitulo)));
            //System.out.println("¡Siguiente capítulo cargado!");
            return true;
        } catch (Exception e) {
            System.out.println("No se encontró el botón 'Siguiente'.");
            return false;
        }
    }

    public void cerrar() {
        if (driver != null) {
            System.out.println("Cerrando el navegador.");
            driver.quit();
        }
    }
}
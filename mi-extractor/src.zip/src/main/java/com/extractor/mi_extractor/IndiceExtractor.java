package com.extractor.mi_extractor;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.util.HashMap;
import java.util.Map;

public class IndiceExtractor {

    private final String selectorFilaCapitulo = "div.skn-nvl-chp-element";

    /**
     * Extrae todos los enlaces a capítulos de un HTML de página de índice.
     * @param html El código HTML de la página.
     * @param urlBase La URL de la página, para resolver enlaces relativos.
     * @return Un mapa donde la clave es el número del capítulo y el valor es la URL completa.
     */
    public Map<Integer, String> extraerEnlaces(String html, String urlBase) {
        Map<Integer, String> mapaDeCapitulos = new HashMap<>();
        // --- CAMBIO CLAVE: Pasamos la urlBase a Jsoup ---
        Document doc = Jsoup.parse(html, urlBase);
        
        Elements filas = doc.select(selectorFilaCapitulo);
        System.out.println("Se encontraron " + filas.size() + " elementos de capítulo en la página.");

        for (Element fila : filas) {
            Element numeroElement = fila.selectFirst("div.skn-nvl-chp-element-chp-number-index");
            Element enlaceElement = fila.selectFirst("a.skn-link");

            if (numeroElement != null && enlaceElement != null) {
                try {
                    int numeroCapitulo = Integer.parseInt(numeroElement.text().trim());
                    // Ahora absUrl("href") funcionará correctamente
                    String url = enlaceElement.absUrl("href");
                    mapaDeCapitulos.put(numeroCapitulo, url);
                } catch (NumberFormatException e) {
                    System.err.println("Advertencia: Se encontró un elemento que no contenía un número de capítulo válido.");
                }
            }
        }
        
        System.out.println("Se procesaron " + mapaDeCapitulos.size() + " enlaces a capítulos con éxito.");
        return mapaDeCapitulos;
    }
}
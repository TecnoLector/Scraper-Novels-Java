package com.extractor.mi_extractor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiExtractorApplicationTests {

	@Test
	void contextLoads() {
	}

}
